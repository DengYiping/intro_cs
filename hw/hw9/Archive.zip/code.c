int main(){
    int a = 0;
    int b = 0;
    do{
        b = b + 1;
        a = a + b;
    } while(b != 10);
    return a;
}
